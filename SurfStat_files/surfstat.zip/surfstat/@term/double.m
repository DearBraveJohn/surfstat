function X=double(t)
X=t.matrix;